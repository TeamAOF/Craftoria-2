Dark Coffee GUI - NormalHunger

Do not distribute or republish anywhere else without permission, the only page that offers this resourcepack is Modrinth and Planet Minecraft, and only by me. If you see any version of this resourcepack anywhere else, do not download, it was uploaded without my supervision and could be dangerous.

Modrinth: https://modrinth.com/resourcepack/dark-coffe-gui
Planet Minecraft: https://www.planetminecraft.com/texture-pack/dark-coffe-gui/
Ko-Fi (if you want 👉👈): https://ko-fi.com/restlesspip